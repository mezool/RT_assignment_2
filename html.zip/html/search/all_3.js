var searchData=
[
  ['further_20improvements_0',['Further improvements',['../md__r_t__assignment__2-main_2_r_e_a_d_m_e.html#autotoc_md7',1,'']]]
];
