var searchData=
[
  ['did_0',['What I did',['../md__r_t__assignment__2-main_2_r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['distance_20and_20average_20velocity_1',['Get target distance and average velocity.',['../md__r_t__assignment__2-main_2_r_e_a_d_m_e.html#autotoc_md5',1,'']]]
];
