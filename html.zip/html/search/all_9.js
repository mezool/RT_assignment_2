var searchData=
[
  ['of_20the_20action_20client_20code_0',['Structure of the action client code',['../md__r_t__assignment__2-main_2_r_e_a_d_m_e.html#autotoc_md6',1,'']]]
];
