var indexSectionsWithContent =
{
  0: "acdfghilnorstvw",
  1: "agr",
  2: "ars"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Pages"
};

