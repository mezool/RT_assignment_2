var searchData=
[
  ['how_20to_20run_0',['How to run',['../md__r_t__assignment__2-main_2_r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
