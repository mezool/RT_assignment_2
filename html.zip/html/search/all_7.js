var searchData=
[
  ['last_20target_20service_0',['Get the last target (service)',['../md__r_t__assignment__2-main_2_r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];
