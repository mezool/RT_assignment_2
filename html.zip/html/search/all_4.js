var searchData=
[
  ['get_20target_20distance_20and_20average_20velocity_0',['Get target distance and average velocity.',['../md__r_t__assignment__2-main_2_r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['get_20the_20last_20target_20service_1',['Get the last target (service)',['../md__r_t__assignment__2-main_2_r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['gettargetpositionnode_2',['GetTargetPositionNode',['../classget__target__position__node_1_1_get_target_position_node.html',1,'get_target_position_node']]]
];
